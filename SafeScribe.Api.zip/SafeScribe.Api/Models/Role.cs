namespace SafeScribe.Api.Models
{
    public enum Role { Leitor = 0, Editor = 1, Admin = 2 }
}
